﻿using RealPage.OneSite.Configuration.DataAccess.DAO;
using RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.Business
{
	public class ConfigurationManager : IConfigurationManager
	{
		private IConfigurationDAO _configDAO = null;
		public ConfigurationManager()
		{
			_configDAO = new ConfigurationDAO();
		}

		public List<ConfigSetUp> GetAllConfig()
		{
			return _configDAO.GetAllConfig();
		}

		public int SaveConfiguration(ConfigSetUp configSetUp)
		{
			return _configDAO.SaveConfiguration(configSetUp);
		}
	}
}
