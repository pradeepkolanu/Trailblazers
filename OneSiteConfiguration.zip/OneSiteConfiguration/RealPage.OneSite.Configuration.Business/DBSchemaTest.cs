﻿using RealPage.OneSite.Configuration.DataAccess.DBInfrastructure;
using RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataModels;
using System;

namespace RealPage.OneSite.Configuration.Business
{
	class DBSchemaTest
	{
		public static void Main(EventArgs args)
		{
			Console.WriteLine("Welcome to DB test...");
			Console.ReadKey();
			int result = 0;
			using (IUnitOfWork unitOfWork = new UnitOfWork(new ConfigurationDBContext()))
			{
				unitOfWork.ConfigSetUpRepository.Add(new ConfigSetUp() { ConfigSetUpID = 1, ConfigSetUpName = "Test" });

				result = unitOfWork.Complete();
			}

			Console.WriteLine("Resut :: " + result.ToString());
		}
	}
}
