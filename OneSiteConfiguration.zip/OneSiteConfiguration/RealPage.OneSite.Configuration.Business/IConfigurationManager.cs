﻿using RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.Business
{
	public interface IConfigurationManager
	{
		List<ConfigSetUp> GetAllConfig();
		int SaveConfiguration(ConfigSetUp configSetUp);
	}
}
