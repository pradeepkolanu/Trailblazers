﻿using RealPage.OneSite.Configuration.DataAccess.DBInfrastructure;
using RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.DataAccess.DAO
{
	public class ConfigurationDAO : IConfigurationDAO
	{
		public List<ConfigSetUp> GetAllConfig()
		{
			List<ConfigSetUp> configs = new List<ConfigSetUp>();
			using (IUnitOfWork _unitOfWork = new UnitOfWork(new ConfigurationDBContext()))
			{
				try
				{
					configs = _unitOfWork.ConfigSetUpRepository.FindAll(item => item.ConfigSetUpID > 0);
				}
				catch (Exception Ex)
				{

				}
			}

			return configs;
		}
		public int SaveConfiguration(ConfigSetUp configSetUp)
		{
			int result = 0;
			using (IUnitOfWork _unitOfWork = new UnitOfWork(new ConfigurationDBContext()))
			{
				try
				{
					_unitOfWork.ConfigSetUpRepository.Add(configSetUp);
					result = _unitOfWork.Complete();
				}
				catch (Exception Ex)
				{
					
				}
			}

			return result;
		}
	}
}
