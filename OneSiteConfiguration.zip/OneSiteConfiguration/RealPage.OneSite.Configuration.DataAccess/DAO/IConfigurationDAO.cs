﻿using RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.DataAccess.DAO
{
	public interface IConfigurationDAO
	{
		List<ConfigSetUp> GetAllConfig();
		int SaveConfiguration(ConfigSetUp configSetUp);
	}
}
