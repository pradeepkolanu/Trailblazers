﻿using RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataModels;
using RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataMappings;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.DataAccess.DBInfrastructure
{
	public class ConfigurationDBContext : DBContextBase
	{
		public ConfigurationDBContext() : base()
		{

		}
		public virtual DbSet<ConfigSetUp> ConfigSetUps { get; set; }
		public virtual DbSet<ConfigSetUpProperty> ConfigSetUpPropertys { get; set; }
		public virtual DbSet<Product> Products { get; set; }
		public virtual DbSet<ProductGroup> ProductGroup { get; set; }
		public virtual DbSet<ProductGroupConfig> ProductGroupConfigs { get; set; }
		public virtual DbSet<ProductSettings> ProductSettings { get; set; }

		protected override void OnModelCreating(DbModelBuilder modelBuilder)
		{
			modelBuilder.Configurations.Add(new ConfigSetUpMapping());
			modelBuilder.Configurations.Add(new ConfigSetUpPropertyMapping());
			modelBuilder.Configurations.Add(new ProductMapping());
			modelBuilder.Configurations.Add(new ProductGroupMapping());
			modelBuilder.Configurations.Add(new ProductGroupConfigMapping());
			modelBuilder.Configurations.Add(new ProductSettingsMapping());

			base.OnModelCreating(modelBuilder);
		}
	}
}
