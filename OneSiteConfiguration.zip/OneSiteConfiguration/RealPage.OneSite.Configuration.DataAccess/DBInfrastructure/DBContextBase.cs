﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.DataAccess.DBInfrastructure
{
	public class DBContextBase : DbContext
	{
		public DBContextBase() : base("default")
		{
			this.Configuration.LazyLoadingEnabled = false;
			this.Configuration.AutoDetectChangesEnabled = false;
			this.Configuration.ProxyCreationEnabled = false;
		}
	}
}
