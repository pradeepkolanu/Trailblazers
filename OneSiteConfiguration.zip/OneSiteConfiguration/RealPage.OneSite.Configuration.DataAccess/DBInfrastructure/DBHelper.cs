﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.DataAccess.DBInfrastructure
{
	public class DBHelper<T> where T : class
	{
		private DBContextBase dbContext { get; set; }
		public DBHelper(DBContextBase context)
		{
			this.dbContext = context;
		}
		public List<T> ExecuteSqlQuery(string SQL, Hashtable parameters)
		{
			List<T> DBResult = null;

			try
			{
				DBResult = this.dbContext.Database.SqlQuery<T>(SQL, parameters).ToList();
			}
			catch (Exception Ex)
			{

			}

			return DBResult;
		}
	}
}
