﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.DataAccess.DBInfrastructure
{
	public interface IDBHelper<T> where T : class
	{
		List<T> ExecuteSqlQuery(string SQL, Hashtable parameters);
	}
}
