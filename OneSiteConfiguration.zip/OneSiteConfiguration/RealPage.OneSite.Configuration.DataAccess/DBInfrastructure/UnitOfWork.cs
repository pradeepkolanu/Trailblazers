﻿using RealPage.OneSite.Configuration.DataAccess.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.DataAccess.DBInfrastructure
{
	public class UnitOfWork : IUnitOfWork
	{
		private DBContextBase dbContext { get; set; }

		public IConfigSetUpRepository ConfigSetUpRepository { get; set; }

		public UnitOfWork(DBContextBase context)
		{
			this.dbContext = context;

			this.ConfigSetUpRepository = new ConfigSetUpRepository(context);
		}

		public int Complete()
		{
			int result = 0;
			try
			{
				result = this.dbContext.SaveChanges();
			}
			catch (Exception Ex)
			{

				throw;
			}

			return result;
		}

		public void Dispose()
		{
			this.dbContext.Dispose();
		}
	}
}
