﻿using RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataModels;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataMappings
{
	public class ConfigSetUpMapping : EntityTypeConfiguration<ConfigSetUp>
	{
		public ConfigSetUpMapping()
		{
			this.ToTable("ConfigSetUp");

			//Primary
			this.HasKey(item => item.ConfigSetUpID);


			//Properties
			this.Property(item => item.ConfigSetUpName).HasMaxLength(100).IsUnicode(false);
			this.Property(item => item.PMCID).HasMaxLength(10).IsUnicode(false);

			//Foriegn
		}
	}
}
