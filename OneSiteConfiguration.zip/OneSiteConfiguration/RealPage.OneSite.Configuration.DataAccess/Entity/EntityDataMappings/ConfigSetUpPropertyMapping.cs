﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.ModelConfiguration;
using RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataModels;

namespace RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataMappings
{
	public class ConfigSetUpPropertyMapping : EntityTypeConfiguration<ConfigSetUpProperty>
	{
		public ConfigSetUpPropertyMapping()
		{
			this.ToTable("ConfigSetUpProperty");

			//Primary
			this.HasKey(item => item.ConfigSetUpPropertyID);


			//Properties
			this.Property(item => item.SiteID).HasMaxLength(10).IsUnicode(false);

			//Foriegn
			this.HasRequired(item => item.ConfigSetup)
				.WithMany(item => item.ConfigSetUpProperty)
				.HasForeignKey(item => item.ConfigSetUpID);
		}
	}
}
