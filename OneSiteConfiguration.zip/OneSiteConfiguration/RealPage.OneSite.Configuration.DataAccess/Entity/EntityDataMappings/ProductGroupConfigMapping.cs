﻿using RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataModels;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataMappings
{
	public class ProductGroupConfigMapping : EntityTypeConfiguration<ProductGroupConfig>
	{
		public ProductGroupConfigMapping()
		{
			this.ToTable("ProductGroupConfig");

			//Primary key
			this.HasKey(item => item.ProductGroupConfigID);

			//Foreign key
			this.HasRequired(item => item.ConfigSetup)
				.WithMany(item => item.ProductGroupConfig)
				.HasForeignKey(item => item.ConfigSetUpID);
		}
	}
}
