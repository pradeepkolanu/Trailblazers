﻿using RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataModels;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataMappings
{
	public class ProductGroupMapping : EntityTypeConfiguration<ProductGroup>
	{
		public ProductGroupMapping()
		{	
			this.ToTable("ProductGroup");

			this.HasKey(item => item.ProductGroupID);

			this.Property(item => item.ProductGroupName).HasMaxLength(100);

			this.HasRequired(item => item.ProductGroupConfig)
				.WithMany(item => item.ProductGroups)
				.HasForeignKey(item => item.ProductGroupConfigID);
		}
	}
}
