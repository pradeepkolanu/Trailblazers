﻿using RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataModels;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataMappings
{
	public class ProductMapping : EntityTypeConfiguration<Product>
	{
		public ProductMapping()
		{
			this.ToTable("Product");

			this.HasKey(item => item.ProductID);

			this.Property(item => item.ProductName).HasMaxLength(100).IsUnicode(false);

			this.HasRequired(item => item.ProductGroup)
				.WithMany(item => item.Products)
				.HasForeignKey(item => item.ProductGroupID);
		}
	}
}
