﻿using RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataModels;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataMappings
{
	public class ProductSettingsMapping : EntityTypeConfiguration<ProductSettings>
	{
		public ProductSettingsMapping()
		{
			this.ToTable("ProductSettings");

			this.HasKey(item => item.ProductSettingsID);

			this.Property(item => item.ProductSettingDesc).HasMaxLength(100).IsUnicode(false);

			this.HasRequired(item => item.Product)
				.WithMany(item => item.ProductSettigs)
				.HasForeignKey(item => item.ProductID);

		}
	}
}
