﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataModels
{
	public class ConfigSetUp
	{
		public ConfigSetUp()
		{
			ConfigSetUpProperty = new HashSet<ConfigSetUpProperty>();
			ProductGroupConfig = new HashSet<ProductGroupConfig>();
		}
		public int ConfigSetUpID { get; set; }
		public string ConfigSetUpName { get; set; }
		public string PMCID { get; set; }

		public virtual ICollection<ConfigSetUpProperty> ConfigSetUpProperty { get; set; }
		public virtual ICollection<ProductGroupConfig> ProductGroupConfig { get; set; }
	}
}
