﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataModels
{
	public class ConfigSetUpProperty
	{
		public int ConfigSetUpPropertyID { get; set; }
		public string SiteID { get; set; }

		public int ConfigSetUpID { get; set; }
		public virtual ConfigSetUp ConfigSetup { get; set; }
	}
}
