﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataModels
{
	public class Product
	{
		public Product()
		{
			ProductSettigs = new HashSet<ProductSettings>();
		}
		public int ProductID { get; set; }
		public string ProductName { get; set; }

		public int ProductGroupID { get; set; }
		public ProductGroup ProductGroup { get; set; }

		public ICollection<ProductSettings> ProductSettigs { get; set; }
	}
}
