﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataModels
{
	public class ProductGroup
	{
		public ProductGroup()
		{
			Products = new HashSet<Product>();
		}
		public int ProductGroupID { get; set; }
		public string ProductGroupName { get; set; }

		public int ProductGroupConfigID { get; set; }
		public ProductGroupConfig ProductGroupConfig { get; set; }

		public ICollection<Product> Products { get; set; }
	}
}
