﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataModels
{
	public class ProductGroupConfig
	{
		public ProductGroupConfig()
		{
			ProductGroups = new HashSet<ProductGroup>();
		}
		public int ProductGroupConfigID { get; set; }
		public int ConfigSetUpID { get; set; }
		public virtual ConfigSetUp ConfigSetup { get; set; }

		public ICollection<ProductGroup> ProductGroups { get; set; }
	}
}
