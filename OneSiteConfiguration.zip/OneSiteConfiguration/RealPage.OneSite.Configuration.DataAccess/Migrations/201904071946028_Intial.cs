namespace RealPage.OneSite.Configuration.DataAccess.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Intial : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ConfigSetUpProperty",
                c => new
                    {
                        ConfigSetUpPropertyID = c.Int(nullable: false, identity: true),
                        SiteID = c.String(maxLength: 10, unicode: false),
                        ConfigSetUpID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ConfigSetUpPropertyID)
                .ForeignKey("dbo.ConfigSetUp", t => t.ConfigSetUpID, cascadeDelete: true)
                .Index(t => t.ConfigSetUpID);
            
            CreateTable(
                "dbo.ConfigSetUp",
                c => new
                    {
                        ConfigSetUpID = c.Int(nullable: false, identity: true),
                        ConfigSetUpName = c.String(maxLength: 100, unicode: false),
                        PMCID = c.String(maxLength: 10, unicode: false),
                    })
                .PrimaryKey(t => t.ConfigSetUpID);
            
            CreateTable(
                "dbo.ProductGroupConfig",
                c => new
                    {
                        ProductGroupConfigID = c.Int(nullable: false, identity: true),
                        ProductGroupID = c.Int(nullable: false),
                        ConfigSetUpID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ProductGroupConfigID)
                .ForeignKey("dbo.ConfigSetUp", t => t.ConfigSetUpID, cascadeDelete: true)
                .Index(t => t.ConfigSetUpID);
            
            CreateTable(
                "dbo.ProductGroup",
                c => new
                    {
                        ProductGroupID = c.Int(nullable: false, identity: true),
                        ProductGroupName = c.String(maxLength: 100),
                        ProductGroupConfigID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ProductGroupID)
                .ForeignKey("dbo.ProductGroupConfig", t => t.ProductGroupConfigID, cascadeDelete: true)
                .Index(t => t.ProductGroupConfigID);
            
            CreateTable(
                "dbo.Product",
                c => new
                    {
                        ProductID = c.Int(nullable: false, identity: true),
                        ProductName = c.String(maxLength: 100, unicode: false),
                        ProductGroupID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ProductID)
                .ForeignKey("dbo.ProductGroup", t => t.ProductGroupID, cascadeDelete: true)
                .Index(t => t.ProductGroupID);
            
            CreateTable(
                "dbo.ProductSettings",
                c => new
                    {
                        ProductSettingsID = c.Int(nullable: false, identity: true),
                        ProductSettingDesc = c.String(maxLength: 100, unicode: false),
                        ProductID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ProductSettingsID)
                .ForeignKey("dbo.Product", t => t.ProductID, cascadeDelete: true)
                .Index(t => t.ProductID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.ConfigSetUpProperty", "ConfigSetUpID", "dbo.ConfigSetUp");
            DropForeignKey("dbo.ProductSettings", "ProductID", "dbo.Product");
            DropForeignKey("dbo.Product", "ProductGroupID", "dbo.ProductGroup");
            DropForeignKey("dbo.ProductGroup", "ProductGroupConfigID", "dbo.ProductGroupConfig");
            DropForeignKey("dbo.ProductGroupConfig", "ConfigSetUpID", "dbo.ConfigSetUp");
            DropIndex("dbo.ProductSettings", new[] { "ProductID" });
            DropIndex("dbo.Product", new[] { "ProductGroupID" });
            DropIndex("dbo.ProductGroup", new[] { "ProductGroupConfigID" });
            DropIndex("dbo.ProductGroupConfig", new[] { "ConfigSetUpID" });
            DropIndex("dbo.ConfigSetUpProperty", new[] { "ConfigSetUpID" });
            DropTable("dbo.ProductSettings");
            DropTable("dbo.Product");
            DropTable("dbo.ProductGroup");
            DropTable("dbo.ProductGroupConfig");
            DropTable("dbo.ConfigSetUp");
            DropTable("dbo.ConfigSetUpProperty");
        }
    }
}
