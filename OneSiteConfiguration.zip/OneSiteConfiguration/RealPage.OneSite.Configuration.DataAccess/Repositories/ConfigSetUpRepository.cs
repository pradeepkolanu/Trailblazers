﻿using RealPage.OneSite.Configuration.DataAccess.DBInfrastructure;
using RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.DataAccess.Repositories
{
	public class ConfigSetUpRepository : GenericRepository<ConfigSetUp>, IConfigSetUpRepository
	{
		private DBContextBase dbContext { get; set; }

		public ConfigSetUpRepository(DBContextBase context) : base(context)
		{
			this.dbContext = context;
		}
	}
}
