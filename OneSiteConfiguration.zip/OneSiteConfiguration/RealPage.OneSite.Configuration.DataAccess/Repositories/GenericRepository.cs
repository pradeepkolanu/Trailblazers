﻿using RealPage.OneSite.Configuration.DataAccess.DBInfrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.DataAccess.Repositories
{
	public class GenericRepository<T> : IGenericRepository<T> where T : class
	{
		private	DBContextBase dbContext { get; set; }

		public GenericRepository(DBContextBase context)
		{
			this.dbContext = context;
		}

		public void Add(T Entity)
		{
			try
			{
				this.dbContext.Set<T>().Add(Entity);
			}
			catch (Exception Ex)
			{
				
			}
		}

		public void Update(T Entity)
		{
			try
			{
				this.dbContext.Entry<T>(Entity).State = System.Data.Entity.EntityState.Modified;
			}
			catch (Exception Ex)
			{

			}
		}

		public void Delete(int EntityID)
		{
			T Entity = null;
			try
			{
				Entity = this.dbContext.Set<T>().Find(EntityID);
				this.dbContext.Entry<T>(Entity).State = System.Data.Entity.EntityState.Deleted;
			}
			catch (	Exception Ex)
			{

			}
		}

		//public int SaveChanges()
		//{
		//	int result = 0;

		//	try
		//	{
		//		result = this.dbContext.SaveChanges();
		//	}
		//	catch (Exception Ex)
		//	{

		//	}

		//	return result;
		//}

		public T Find(int EntityID)
		{
			T Entity = null;

			try
			{
				Entity = this.dbContext.Set<T>().Find(EntityID);
			}
			catch (Exception Ex)
			{

			}

			return Entity;
		}

		public List<T> FindAll(Func<T,bool> predicate)
		{
			List<T> EntityAll = new List<T>();

			try
			{
				EntityAll = this.dbContext.Set<T>().Where(predicate).ToList();
			}
			catch (Exception Ex)
			{

			}

			return EntityAll;
		}

		public int Count(T Entity)
		{
			int count = 0;

			try
			{
				count = this.dbContext.Set<T>().Count();
			}
			catch (Exception Ex)
			{

			}

			return count;
		}
	}
}
