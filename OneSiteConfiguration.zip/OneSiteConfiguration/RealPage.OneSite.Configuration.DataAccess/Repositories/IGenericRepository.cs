﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealPage.OneSite.Configuration.DataAccess.Repositories
{
	public interface IGenericRepository<T> where T : class
	{
		void Add(T Entity);
		void Update(T Entity);
		void Delete(int EntityID);
		T Find(int EntityID);
		List<T> FindAll(Func<T, bool> predicate);
		int Count(T Entity);
	}
}
