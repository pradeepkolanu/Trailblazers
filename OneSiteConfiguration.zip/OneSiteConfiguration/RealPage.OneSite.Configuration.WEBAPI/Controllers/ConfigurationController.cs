﻿using RealPage.OneSite.Configuration.Business;
using RealPage.OneSite.Configuration.DataAccess.Entity.EntityDataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Controllers;

namespace RealPage.OneSite.Configuration.WEBAPI.Controllers
{
    public class ConfigurationController : ApiController
    {
		private IConfigurationManager _configManager = null;
		protected override void Initialize(HttpControllerContext controllerContext)
		{
			_configManager = new ConfigurationManager();
			base.Initialize(controllerContext);
		}
		// GET: api/Configuration
		public List<ConfigSetUp> Get()
        {
			return _configManager.GetAllConfig();
        }

        // GET: api/Configuration/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Configuration
        public HttpResponseMessage Post([FromBody]ConfigSetUp configSetUp)
        {
			int result = 0;
			if(!ModelState.IsValid)
			{
				return Request.CreateErrorResponse(HttpStatusCode.BadRequest,ModelState);
			}

			try
			{
				result = _configManager.SaveConfiguration(configSetUp);
			}
			catch (Exception Ex)
			{

			}

			return  Request.CreateResponse(HttpStatusCode.OK, result);
        }

        // PUT: api/Configuration/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Configuration/5
        public void Delete(int id)
        {
        }
    }
}
